package org.openqa.selenium.internal;

/**
 * @deprecated Use {@link org.openqa.selenium.BuildInfo} instead.
 */
@Deprecated
public class BuildInfo extends org.openqa.selenium.BuildInfo {

}
